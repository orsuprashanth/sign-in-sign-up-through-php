<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: index.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="logo">
                <h1>Auth System</h1>
            </div>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </header>
        
        <main class="dashboard-content">
            <div class="welcome-card">
                <h2>Welcome to Your Dashboard</h2>
                <p>You have successfully logged in to the secure area.</p>
                <p>This is a protected page that only authenticated users can access.</p>
            </div>
            
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Account Created</h3>
                    <p><?php 
                        require_once "config.php";
                        $sql = "SELECT created_at FROM users WHERE id = ?";
                        if ($stmt = mysqli_prepare($conn, $sql)) {
                            mysqli_stmt_bind_param($stmt, "i", $_SESSION["id"]);
                            if (mysqli_stmt_execute($stmt)) {
                                mysqli_stmt_bind_result($stmt, $created_at);
                                if (mysqli_stmt_fetch($stmt)) {
                                    echo date("F j, Y", strtotime($created_at));
                                }
                            }
                            mysqli_stmt_close($stmt);
                        }
                        mysqli_close($conn);
                    ?></p>
                </div>
                
                <div class="stat-card">
                    <h3>User ID</h3>
                    <p><?php echo htmlspecialchars($_SESSION["id"]); ?></p>
                </div>
                
                <div class="stat-card">
                    <h3>Email</h3>
                    <p><?php 
                        require_once "config.php";
                        $sql = "SELECT email FROM users WHERE id = ?";
                        if ($stmt = mysqli_prepare($conn, $sql)) {
                            mysqli_stmt_bind_param($stmt, "i", $_SESSION["id"]);
                            if (mysqli_stmt_execute($stmt)) {
                                mysqli_stmt_bind_result($stmt, $email);
                                if (mysqli_stmt_fetch($stmt)) {
                                    echo htmlspecialchars($email);
                                }
                            }
                            mysqli_stmt_close($stmt);
                        }
                        mysqli_close($conn);
                    ?></p>
                </div>
            </div>
        </main>
        
        <footer class="dashboard-footer">
            <p>&copy; 2025 Authentication System. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>