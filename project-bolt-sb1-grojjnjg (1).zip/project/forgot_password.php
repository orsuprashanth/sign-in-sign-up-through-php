<?php
// Include config file
require_once "config.php";

$email = $email_err = "";
$show_form = true;
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
        
        // Check if email exists
        $sql = "SELECT id FROM users WHERE email = ?";
        
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = $email;
            
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    // Email exists, in a real application, send a password reset email
                    $show_form = false;
                    $message = "If an account with that email exists, we've sent a password reset link.";
                } else {
                    // For security, don't reveal if the email doesn't exist
                    $show_form = false;
                    $message = "If an account with that email exists, we've sent a password reset link.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            
            mysqli_stmt_close($stmt);
        }
    }
    
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <div class="auth-container">
            <div class="forms-container">
                <?php if ($show_form): ?>
                <form class="form active" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <h2>Forgot Password</h2>
                    <p>Enter your email address and we'll send you a link to reset your password.</p>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                        <span class="error"><?php echo $email_err; ?></span>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Send Reset Link</button>
                    
                    <div class="form-footer">
                        <a href="index.php">Back to Login</a>
                    </div>
                </form>
                <?php else: ?>
                <div class="form active">
                    <h2>Email Sent</h2>
                    <p><?php echo $message; ?></p>
                    <div class="form-footer">
                        <a href="index.php">Back to Login</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>