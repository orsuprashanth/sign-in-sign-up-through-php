# PHP & MySQL Authentication System

A secure and user-friendly authentication system built with PHP and MySQL.

## Features

- User registration with username, email, and password
- Secure login with email and password
- Password hashing for enhanced security
- Session management for authenticated users
- Error handling with appropriate messages
- Responsive design for all devices
- Forgot password functionality

## Requirements

- PHP 7.0 or higher
- MySQL 5.6 or higher
- Web server (Apache, Nginx, etc.)

## Installation

1. Clone or download this repository to your web server directory
2. Create a MySQL database (the system will attempt to create one named 'auth_system')
3. Update the database configuration in `config.php` if needed
4. Access the application through your web browser

## Database Configuration

The default database configuration is:

```php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'auth_system');
```

Update these values in `config.php` to match your database settings.

## Security Features

- Password hashing using PHP's password_hash() function
- Prepared statements to prevent SQL injection
- Input validation and sanitization
- Session management for authenticated users
- Protection against common web vulnerabilities

## File Structure

- `index.php` - Main entry point with login/signup forms
- `config.php` - Database configuration and connection
- `signup_process.php` - Handles user registration
- `login_process.php` - Handles user authentication
- `dashboard.php` - Protected page for authenticated users
- `logout.php` - Handles user logout
- `forgot_password.php` - Password recovery functionality
- `css/styles.css` - Stylesheet for the application
- `js/script.js` - JavaScript for interactive elements

## License

This project is open-source and available under the MIT License.