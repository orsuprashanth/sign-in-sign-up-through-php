<?php
session_start();
// Redirect to dashboard if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication System</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <div class="auth-container">
            <div class="tabs">
                <button class="tab-btn active" data-target="login-form">Login</button>
                <button class="tab-btn" data-target="signup-form">Sign Up</button>
            </div>
            
            <div class="forms-container">
                <!-- Login Form -->
                <form id="login-form" class="form active" action="login_process.php" method="post">
                    <h2>Welcome Back</h2>
                    <?php if (isset($_GET['error']) && $_GET['error'] === 'invalid'): ?>
                        <div class="error-message">Invalid email or password</div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="login-email">Email</label>
                        <input type="email" id="login-email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="login-password">Password</label>
                        <input type="password" id="login-password" name="password" required>
                    </div>
                    
                    <div class="form-group remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember">Remember me</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Login</button>
                    
                    <div class="form-footer">
                        <a href="forgot_password.php">Forgot Password?</a>
                    </div>
                </form>
                
                <!-- Signup Form -->
                <form id="signup-form" class="form" action="signup_process.php" method="post">
                    <h2>Create Account</h2>
                    <?php if (isset($_GET['error']) && $_GET['error'] === 'email_exists'): ?>
                        <div class="error-message">Email already exists</div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="signup-username">Username</label>
                        <input type="text" id="signup-username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="signup-email">Email</label>
                        <input type="email" id="signup-email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="signup-password">Password</label>
                        <input type="password" id="signup-password" name="password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password</label>
                        <input type="password" id="confirm-password" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                    
                    <div class="form-footer">
                        <p>By signing up, you agree to our <a href="#">Terms</a> and <a href="#">Privacy Policy</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="js/script.js"></script>
</body>
</html>